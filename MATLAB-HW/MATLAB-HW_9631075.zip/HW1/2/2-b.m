x = -20:20;
y = 5*cos(3*x);
stem(x,y,'filled','MarkerSize',2);
title('HW1 2-b');
xlabel('n');
ylabel('x[n]');
